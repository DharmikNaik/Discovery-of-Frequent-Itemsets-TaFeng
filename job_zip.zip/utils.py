def flattenList(nonFlatList):
    return [item for sublist in nonFlatList for item in sublist]