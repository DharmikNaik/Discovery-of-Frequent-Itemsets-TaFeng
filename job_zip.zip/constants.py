import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
# DIR_INPUT_RAW = os.path.join(PROJECT_ROOT, 'data', 'raw')
# DIR_OUT_PROCESSED = os.path.join(PROJECT_ROOT, 'data', 'processed')